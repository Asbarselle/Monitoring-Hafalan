<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Santri;
use App\Models\Hafalan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:admin');
    }

    /**
     * Dashboard Admin
     */
    public function dashboard()
    {
        $totalUsers = User::count();
        $totalSantri = Santri::count();
        $totalHafalan = Hafalan::count();
        $hafalanSelesai = Hafalan::where('status', 'selesai')->count();
        
        $statistikHafalan = Hafalan::selectRaw('status, COUNT(*) as total')
            ->groupBy('status')
            ->get();

        return view('admin.dashboard', compact('totalUsers', 'totalSantri', 'totalHafalan', 'hafalanSelesai', 'statistikHafalan'));
    }

    /**
     * Kelola User
     */
    public function users()
    {
        $users = User::with('santri')->latest()->paginate(10);
        return view('admin.users.index', compact('users'));
    }

    public function createUser()
    {
        return view('admin.users.create');
    }

    public function storeUser(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:8|confirmed',
            'role' => 'required|in:admin,ustadz,orang_tua',
        ]);

        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => $request->role,
        ]);

        return redirect()->route('admin.users')->with('success', 'User berhasil ditambahkan.');
    }

    public function editUser($id)
    {
        $user = User::findOrFail($id);
        return view('admin.users.edit', compact('user'));
    }

    public function updateUser(Request $request, $id)
    {
        $user = User::findOrFail($id);
        
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $id,
            'password' => 'nullable|string|min:8|confirmed',
            'role' => 'required|in:admin,ustadz,orang_tua',
        ]);

        $data = [
            'name' => $request->name,
            'email' => $request->email,
            'role' => $request->role,
        ];

        if ($request->filled('password')) {
            $data['password'] = Hash::make($request->password);
        }

        $user->update($data);

        return redirect()->route('admin.users')->with('success', 'User berhasil diperbarui.');
    }

    public function destroyUser($id)
    {
        $user = User::findOrFail($id);
        $user->delete();

        return redirect()->route('admin.users')->with('success', 'User berhasil dihapus.');
    }

    /**
     * Kelola Santri
     */
    public function santri()
    {
        $santri = Santri::with('orangTua')->latest()->paginate(10);
        return view('admin.santri.index', compact('santri'));
    }

    public function createSantri()
    {
        $orangTua = User::where('role', 'orang_tua')->get();
        return view('admin.santri.create', compact('orangTua'));
    }

    public function storeSantri(Request $request)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'nis' => 'required|string|unique:santri,nis',
            'tempat_lahir' => 'nullable|string',
            'tanggal_lahir' => 'nullable|date',
            'jenis_kelamin' => 'nullable|in:L,P',
            'alamat' => 'nullable|string',
            'no_hp' => 'nullable|string',
            'foto' => 'nullable|image|max:2048',
            'orang_tua_id' => 'nullable|exists:users,id',
        ]);

        $data = $request->except('foto');
        
        if ($request->hasFile('foto')) {
            $data['foto'] = $request->file('foto')->store('santri', 'public');
        }

        Santri::create($data);

        return redirect()->route('admin.santri')->with('success', 'Santri berhasil ditambahkan.');
    }

    public function editSantri($id)
    {
        $santri = Santri::findOrFail($id);
        $orangTua = User::where('role', 'orang_tua')->get();
        return view('admin.santri.edit', compact('santri', 'orangTua'));
    }

    public function updateSantri(Request $request, $id)
    {
        $santri = Santri::findOrFail($id);
        
        $request->validate([
            'nama' => 'required|string|max:255',
            'nis' => 'required|string|unique:santri,nis,' . $id,
            'tempat_lahir' => 'nullable|string',
            'tanggal_lahir' => 'nullable|date',
            'jenis_kelamin' => 'nullable|in:L,P',
            'alamat' => 'nullable|string',
            'no_hp' => 'nullable|string',
            'foto' => 'nullable|image|max:2048',
            'orang_tua_id' => 'nullable|exists:users,id',
        ]);

        $data = $request->except('foto');
        
        if ($request->hasFile('foto')) {
            if ($santri->foto) {
                Storage::disk('public')->delete($santri->foto);
            }
            $data['foto'] = $request->file('foto')->store('santri', 'public');
        }

        $santri->update($data);

        return redirect()->route('admin.santri')->with('success', 'Santri berhasil diperbarui.');
    }

    public function destroySantri($id)
    {
        $santri = Santri::findOrFail($id);
        if ($santri->foto) {
            Storage::disk('public')->delete($santri->foto);
        }
        $santri->delete();

        return redirect()->route('admin.santri')->with('success', 'Santri berhasil dihapus.');
    }

    /**
     * Kelola Hafalan
     */
    public function hafalan()
    {
        $hafalan = Hafalan::with(['santri', 'ustadz'])->latest()->paginate(10);
        return view('admin.hafalan.index', compact('hafalan'));
    }
}
