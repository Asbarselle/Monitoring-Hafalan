<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Tampilkan halaman beranda
     */
    public function index()
    {
        return view('home.index');
    }

    /**
     * Tampilkan halaman tentang kami
     */
    public function tentang()
    {
        return view('home.tentang');
    }

    /**
     * Tampilkan halaman info
     */
    public function info()
    {
        return view('home.info');
    }
}
