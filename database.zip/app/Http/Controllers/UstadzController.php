<?php

namespace App\Http\Controllers;

use App\Models\Santri;
use App\Models\Hafalan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UstadzController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:ustadz');
    }

    /**
     * Dashboard Ustadz
     */
    public function dashboard()
    {
        $ustadzId = Auth::id();
        $totalSantri = Santri::count();
        $totalHafalan = Hafalan::where('ustadz_id', $ustadzId)->count();
        $hafalanSelesai = Hafalan::where('ustadz_id', $ustadzId)->where('status', 'selesai')->count();
        
        $hafalanTerbaru = Hafalan::where('ustadz_id', $ustadzId)
            ->with('santri')
            ->latest()
            ->take(5)
            ->get();

        return view('ustadz.dashboard', compact('totalSantri', 'totalHafalan', 'hafalanSelesai', 'hafalanTerbaru'));
    }

    /**
     * Daftar semua santri
     */
    public function index()
    {
        $santri = Santri::with(['hafalan' => function($query) {
            $query->where('ustadz_id', Auth::id())->latest();
        }])->latest()->paginate(10);

        return view('ustadz.santri.index', compact('santri'));
    }

    /**
     * Tampilkan hafalan santri tertentu
     */
    public function show($id)
    {
        $santri = Santri::with(['hafalan' => function($query) {
            $query->where('ustadz_id', Auth::id())->latest();
        }])->findOrFail($id);

        return view('ustadz.santri.show', compact('santri'));
    }

    /**
     * Form tambah hafalan
     */
    public function create($santriId)
    {
        $santri = Santri::findOrFail($santriId);
        return view('ustadz.hafalan.create', compact('santri'));
    }

    /**
     * Simpan hafalan baru
     */
    public function store(Request $request)
    {
        $request->validate([
            'santri_id' => 'required|exists:santri,id',
            'juz' => 'nullable|integer|min:1|max:30',
            'surat' => 'nullable|string|max:255',
            'ayat_dari' => 'nullable|string|max:50',
            'ayat_sampai' => 'nullable|string|max:50',
            'status' => 'required|in:belum,sedang,selesai,mengulang',
            'catatan' => 'nullable|string',
            'tanggal_setoran' => 'nullable|date',
            'nilai' => 'nullable|integer|min:0|max:100',
        ]);

        Hafalan::create([
            'santri_id' => $request->santri_id,
            'ustadz_id' => Auth::id(),
            'juz' => $request->juz,
            'surat' => $request->surat,
            'ayat_dari' => $request->ayat_dari,
            'ayat_sampai' => $request->ayat_sampai,
            'status' => $request->status,
            'catatan' => $request->catatan,
            'tanggal_setoran' => $request->tanggal_setoran,
            'nilai' => $request->nilai,
        ]);

        return redirect()->route('ustadz.santri.show', $request->santri_id)
            ->with('success', 'Hafalan berhasil ditambahkan.');
    }

    /**
     * Form edit hafalan
     */
    public function edit($id)
    {
        $hafalan = Hafalan::where('ustadz_id', Auth::id())->findOrFail($id);
        return view('ustadz.hafalan.edit', compact('hafalan'));
    }

    /**
     * Update hafalan
     */
    public function update(Request $request, $id)
    {
        $hafalan = Hafalan::where('ustadz_id', Auth::id())->findOrFail($id);
        
        $request->validate([
            'juz' => 'nullable|integer|min:1|max:30',
            'surat' => 'nullable|string|max:255',
            'ayat_dari' => 'nullable|string|max:50',
            'ayat_sampai' => 'nullable|string|max:50',
            'status' => 'required|in:belum,sedang,selesai,mengulang',
            'catatan' => 'nullable|string',
            'tanggal_setoran' => 'nullable|date',
            'nilai' => 'nullable|integer|min:0|max:100',
        ]);

        $hafalan->update($request->all());

        return redirect()->route('ustadz.santri.show', $hafalan->santri_id)
            ->with('success', 'Hafalan berhasil diperbarui.');
    }

    /**
     * Hapus hafalan
     */
    public function destroy($id)
    {
        $hafalan = Hafalan::where('ustadz_id', Auth::id())->findOrFail($id);
        $santriId = $hafalan->santri_id;
        $hafalan->delete();

        return redirect()->route('ustadz.santri.show', $santriId)
            ->with('success', 'Hafalan berhasil dihapus.');
    }
}
