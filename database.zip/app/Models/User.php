<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    /**
     * Relasi dengan Santri (jika role adalah orang_tua)
     */
    public function santri()
    {
        return $this->hasMany(Santri::class, 'orang_tua_id');
    }

    /**
     * Relasi dengan Hafalan (jika role adalah ustadz)
     */
    public function hafalan()
    {
        return $this->hasMany(Hafalan::class, 'ustadz_id');
    }

    /**
     * Cek apakah user adalah admin
     */
    public function isAdmin()
    {
        return $this->role === 'admin';
    }

    /**
     * Cek apakah user adalah ustadz
     */
    public function isUstadz()
    {
        return $this->role === 'ustadz';
    }

    /**
     * Cek apakah user adalah orang tua
     */
    public function isOrangTua()
    {
        return $this->role === 'orang_tua';
    }
}
