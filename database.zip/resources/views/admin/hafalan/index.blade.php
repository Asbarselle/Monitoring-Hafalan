@extends('layouts.app')

@section('title', 'Data Hafalan - SIMHAFAL')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="bi bi-book"></i> Data Hafalan</h2>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Santri</th>
                        <th>Juz</th>
                        <th>Surat</th>
                        <th>Ayat</th>
                        <th>Status</th>
                        <th>Ustadz</th>
                        <th>Tanggal Setoran</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($hafalan as $h)
                        <tr>
                            <td>{{ $loop->iteration + ($hafalan->currentPage() - 1) * $hafalan->perPage() }}</td>
                            <td>{{ $h->santri->nama }}</td>
                            <td>{{ $h->juz ?? '-' }}</td>
                            <td>{{ $h->surat ?? '-' }}</td>
                            <td>{{ $h->ayat_dari && $h->ayat_sampai ? $h->ayat_dari . '-' . $h->ayat_sampai : '-' }}</td>
                            <td>
                                <span class="badge bg-{{ $h->status == 'selesai' ? 'success' : ($h->status == 'sedang' ? 'warning' : ($h->status == 'mengulang' ? 'danger' : 'secondary')) }}">
                                    {{ ucfirst($h->status) }}
                                </span>
                            </td>
                            <td>{{ $h->ustadz ? $h->ustadz->name : '-' }}</td>
                            <td>{{ $h->tanggal_setoran ? $h->tanggal_setoran->format('d/m/Y') : '-' }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8" class="text-center">Tidak ada data</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            {{ $hafalan->links() }}
        </div>
    </div>
</div>
@endsection
