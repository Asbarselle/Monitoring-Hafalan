

<?php $__env->startSection('title', 'Beranda - SIMHAFAL'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body text-center p-5">
                <h1 class="display-4 mb-3">Pondok Pesantren Hilyatul Irsyad</h1>
                <p class="lead">Sistem Informasi Monitoring Hafalan Al-Qur'an</p>
            </div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-6 mb-3">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><i class="bi bi-info-circle"></i> Tentang Pondok</h5>
                <p class="card-text">
                    Pondok Pesantren Hilyatul Irsyad adalah lembaga pendidikan Islam yang berkomitmen 
                    untuk membina generasi yang hafal Al-Qur'an dan berakhlak mulia. Dengan sistem 
                    monitoring yang terintegrasi, kami memastikan setiap santri mendapatkan 
                    pendampingan optimal dalam menghafal Al-Qur'an.
                </p>
            </div>
        </div>
    </div>
    <div class="col-md-6 mb-3">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><i class="bi bi-book"></i> Program Hafalan</h5>
                <p class="card-text">
                    Program hafalan Al-Qur'an di Pondok Pesantren Hilyatul Irsyad dirancang secara 
                    sistematis dengan pendampingan ustadz yang berpengalaman. Setiap perkembangan 
                    hafalan santri dapat dipantau secara real-time melalui sistem monitoring ini.
                </p>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-images"></i> Galeri Pondok</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <div class="bg-secondary text-white p-5 text-center rounded">
                            <i class="bi bi-image" style="font-size: 3rem;"></i>
                            <p class="mt-2">Foto Pondok</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="bg-secondary text-white p-5 text-center rounded">
                            <i class="bi bi-image" style="font-size: 3rem;"></i>
                            <p class="mt-2">Aktivitas Santri</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="bg-secondary text-white p-5 text-center rounded">
                            <i class="bi bi-image" style="font-size: 3rem;"></i>
                            <p class="mt-2">Kegiatan Hafalan</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\SIMHAFAL\resources\views/home/index.blade.php ENDPATH**/ ?>