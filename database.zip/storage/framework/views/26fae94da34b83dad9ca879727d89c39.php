

<?php $__env->startSection('title', 'Detail Santri - SIMHAFAL'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="bi bi-person-badge"></i> Detail Santri: <?php echo e($santri->nama); ?></h2>
    <a href="<?php echo e(route('ustadz.santri.index')); ?>" class="btn btn-secondary">
        <i class="bi bi-arrow-left"></i> Kembali
    </a>
</div>

<div class="row mb-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Informasi Santri</h5>
            </div>
            <div class="card-body">
                <p><strong>NIS:</strong> <?php echo e($santri->nis); ?></p>
                <p><strong>Nama:</strong> <?php echo e($santri->nama); ?></p>
                <p><strong>Jenis Kelamin:</strong> <?php echo e($santri->jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'); ?></p>
                <p><strong>Alamat:</strong> <?php echo e($santri->alamat ?? '-'); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Statistik Hafalan</h5>
            </div>
            <div class="card-body">
                <p><strong>Total Juz:</strong> <?php echo e($santri->total_juz); ?> / 30</p>
                <p><strong>Progres:</strong></p>
                <div class="progress mb-2">
                    <div class="progress-bar" role="progressbar" 
                         style="width: <?php echo e($santri->progres_hafalan); ?>%">
                        <?php echo e(number_format($santri->progres_hafalan, 1)); ?>%
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Data Hafalan</h5>
        <a href="<?php echo e(route('ustadz.hafalan.create', $santri->id)); ?>" class="btn btn-sm btn-primary">
            <i class="bi bi-plus-circle"></i> Tambah Hafalan
        </a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Juz</th>
                        <th>Surat</th>
                        <th>Ayat</th>
                        <th>Status</th>
                        <th>Tanggal Setoran</th>
                        <th>Nilai</th>
                        <th>Catatan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $santri->hafalan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($h->juz ?? '-'); ?></td>
                            <td><?php echo e($h->surat ?? '-'); ?></td>
                            <td><?php echo e($h->ayat_dari && $h->ayat_sampai ? $h->ayat_dari . '-' . $h->ayat_sampai : '-'); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($h->status == 'selesai' ? 'success' : ($h->status == 'sedang' ? 'warning' : ($h->status == 'mengulang' ? 'danger' : 'secondary'))); ?>">
                                    <?php echo e(ucfirst($h->status)); ?>

                                </span>
                            </td>
                            <td><?php echo e($h->tanggal_setoran ? $h->tanggal_setoran->format('d/m/Y') : '-'); ?></td>
                            <td><?php echo e($h->nilai ?? '-'); ?></td>
                            <td><?php echo e(\Illuminate\Support\Str::limit($h->catatan ?? '-', 30)); ?></td>
                            <td>
                                <a href="<?php echo e(route('ustadz.hafalan.edit', $h->id)); ?>" class="btn btn-sm btn-warning">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="<?php echo e(route('ustadz.hafalan.destroy', $h->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" 
                                            onclick="return confirm('Yakin ingin menghapus?')">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="text-center">Belum ada data hafalan</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\SIMHAFAL\resources\views/ustadz/santri/show.blade.php ENDPATH**/ ?>