

<?php $__env->startSection('title', 'Dashboard Orang Tua - SIMHAFAL'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="bi bi-speedometer2"></i> Dashboard Monitoring Hafalan</h2>
</div>

<?php if($santri->isEmpty()): ?>
    <div class="alert alert-info">
        <i class="bi bi-info-circle"></i> Belum ada data santri yang terhubung dengan akun Anda. 
        Silakan hubungi administrator untuk menghubungkan akun Anda dengan data santri.
    </div>
<?php else: ?>
    <div class="row mb-4">
        <?php $__currentLoopData = $santri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 mb-3">
                <div class="card stat-card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="bi bi-person-badge"></i> <?php echo e($s->nama); ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <strong>NIS:</strong> <?php echo e($s->nis); ?><br>
                            <strong>Total Juz:</strong> <?php echo e($statistik[$s->id]['total_juz'] ?? 0); ?> / 30
                        </div>
                        <div class="mb-2">
                            <strong>Progres Hafalan:</strong>
                            <div class="progress mt-2">
                                <div class="progress-bar" role="progressbar" 
                                     style="width: <?php echo e($statistik[$s->id]['progres'] ?? 0); ?>%">
                                    <?php echo e(number_format($statistik[$s->id]['progres'] ?? 0, 1)); ?>%
                                </div>
                            </div>
                        </div>
                        <div class="row text-center mt-3">
                            <div class="col-6">
                                <div class="border-end">
                                    <h4 class="mb-0"><?php echo e($statistik[$s->id]['total_hafalan'] ?? 0); ?></h4>
                                    <small class="text-muted">Total Hafalan</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <h4 class="mb-0"><?php echo e($statistik[$s->id]['hafalan_selesai'] ?? 0); ?></h4>
                                <small class="text-muted">Selesai</small>
                            </div>
                        </div>
                        <div class="mt-3">
                            <a href="<?php echo e(route('parent.santri.show', $s->id)); ?>" class="btn btn-primary btn-sm w-100">
                                <i class="bi bi-eye"></i> Lihat Detail
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="card">
        <div class="card-header">
            <h5 class="mb-0"><i class="bi bi-clock-history"></i> Hafalan Terbaru</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Santri</th>
                            <th>Juz</th>
                            <th>Surat</th>
                            <th>Ayat</th>
                            <th>Status</th>
                            <th>Ustadz</th>
                            <th>Tanggal Setoran</th>
                            <th>Catatan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $hafalanTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($h->santri->nama); ?></td>
                                <td><?php echo e($h->juz ?? '-'); ?></td>
                                <td><?php echo e($h->surat ?? '-'); ?></td>
                                <td><?php echo e($h->ayat_dari && $h->ayat_sampai ? $h->ayat_dari . '-' . $h->ayat_sampai : '-'); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo e($h->status == 'selesai' ? 'success' : ($h->status == 'sedang' ? 'warning' : ($h->status == 'mengulang' ? 'danger' : 'secondary'))); ?>">
                                        <?php echo e(ucfirst($h->status)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($h->ustadz ? $h->ustadz->name : '-'); ?></td>
                                <td><?php echo e($h->tanggal_setoran ? $h->tanggal_setoran->format('d/m/Y') : '-'); ?></td>
                                <td><?php echo e(\Illuminate\Support\Str::limit($h->catatan ?? '-', 30)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center">Belum ada data hafalan</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\SIMHAFAL\resources\views/parent/dashboard.blade.php ENDPATH**/ ?>