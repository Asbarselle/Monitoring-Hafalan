

<?php $__env->startSection('title', 'Data Hafalan - SIMHAFAL'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="bi bi-book"></i> Data Hafalan</h2>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Santri</th>
                        <th>Juz</th>
                        <th>Surat</th>
                        <th>Ayat</th>
                        <th>Status</th>
                        <th>Ustadz</th>
                        <th>Tanggal Setoran</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $hafalan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration + ($hafalan->currentPage() - 1) * $hafalan->perPage()); ?></td>
                            <td><?php echo e($h->santri->nama); ?></td>
                            <td><?php echo e($h->juz ?? '-'); ?></td>
                            <td><?php echo e($h->surat ?? '-'); ?></td>
                            <td><?php echo e($h->ayat_dari && $h->ayat_sampai ? $h->ayat_dari . '-' . $h->ayat_sampai : '-'); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($h->status == 'selesai' ? 'success' : ($h->status == 'sedang' ? 'warning' : ($h->status == 'mengulang' ? 'danger' : 'secondary'))); ?>">
                                    <?php echo e(ucfirst($h->status)); ?>

                                </span>
                            </td>
                            <td><?php echo e($h->ustadz ? $h->ustadz->name : '-'); ?></td>
                            <td><?php echo e($h->tanggal_setoran ? $h->tanggal_setoran->format('d/m/Y') : '-'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center">Tidak ada data</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            <?php echo e($hafalan->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\SIMHAFAL\resources\views/admin/hafalan/index.blade.php ENDPATH**/ ?>