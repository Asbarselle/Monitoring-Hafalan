

<?php $__env->startSection('title', 'Detail Hafalan - SIMHAFAL'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="bi bi-book"></i> Detail Hafalan: <?php echo e($santri->nama); ?></h2>
    <a href="<?php echo e(route('parent.dashboard')); ?>" class="btn btn-secondary">
        <i class="bi bi-arrow-left"></i> Kembali
    </a>
</div>

<div class="row mb-4">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Informasi Santri</h5>
            </div>
            <div class="card-body">
                <p><strong>NIS:</strong> <?php echo e($santri->nis); ?></p>
                <p><strong>Nama:</strong> <?php echo e($santri->nama); ?></p>
                <p><strong>Jenis Kelamin:</strong> <?php echo e($santri->jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Statistik Hafalan</h5>
            </div>
            <div class="card-body">
                <div class="row text-center">
                    <div class="col-4">
                        <h3 class="mb-0"><?php echo e($santri->total_juz); ?></h3>
                        <small class="text-muted">Juz Selesai</small>
                    </div>
                    <div class="col-4">
                        <h3 class="mb-0"><?php echo e($santri->hafalan->count()); ?></h3>
                        <small class="text-muted">Total Hafalan</small>
                    </div>
                    <div class="col-4">
                        <h3 class="mb-0"><?php echo e(number_format($santri->progres_hafalan, 1)); ?>%</h3>
                        <small class="text-muted">Progres</small>
                    </div>
                </div>
                <div class="progress mt-3">
                    <div class="progress-bar" role="progressbar" 
                         style="width: <?php echo e($santri->progres_hafalan); ?>%">
                        <?php echo e(number_format($santri->progres_hafalan, 1)); ?>%
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Data Hafalan</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Juz</th>
                        <th>Surat</th>
                        <th>Ayat Dari</th>
                        <th>Ayat Sampai</th>
                        <th>Status</th>
                        <th>Tanggal Setoran</th>
                        <th>Nilai</th>
                        <th>Catatan</th>
                        <th>Ustadz</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $hafalan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration + ($hafalan->currentPage() - 1) * $hafalan->perPage()); ?></td>
                            <td><?php echo e($h->juz ?? '-'); ?></td>
                            <td><?php echo e($h->surat ?? '-'); ?></td>
                            <td><?php echo e($h->ayat_dari ?? '-'); ?></td>
                            <td><?php echo e($h->ayat_sampai ?? '-'); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($h->status == 'selesai' ? 'success' : ($h->status == 'sedang' ? 'warning' : ($h->status == 'mengulang' ? 'danger' : 'secondary'))); ?>">
                                    <?php echo e(ucfirst($h->status)); ?>

                                </span>
                            </td>
                            <td><?php echo e($h->tanggal_setoran ? $h->tanggal_setoran->format('d/m/Y') : '-'); ?></td>
                            <td><?php echo e($h->nilai ?? '-'); ?></td>
                            <td><?php echo e($h->catatan ?? '-'); ?></td>
                            <td><?php echo e($h->ustadz ? $h->ustadz->name : '-'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="10" class="text-center">Belum ada data hafalan</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            <?php echo e($hafalan->links()); ?>

        </div>
    </div>
</div>

<?php if(isset($statistikJuz) && $statistikJuz->isNotEmpty()): ?>
<div class="card mt-4">
    <div class="card-header">
        <h5 class="mb-0">Statistik Per Juz</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <?php $__currentLoopData = $statistikJuz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juz => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <h6>Juz <?php echo e($juz); ?></h6>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <small class="d-block">
                                    <?php echo e(ucfirst($stat->status)); ?>: <?php echo e($stat->total); ?>

                                </small>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\SIMHAFAL\resources\views/parent/santri/show.blade.php ENDPATH**/ ?>