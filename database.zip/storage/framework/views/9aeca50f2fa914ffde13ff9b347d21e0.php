

<?php $__env->startSection('title', 'Info - SIMHAFAL'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-calendar-event"></i> Informasi Pendaftaran</h5>
            </div>
            <div class="card-body">
                <p><strong>Waktu Pendaftaran:</strong> Setiap tahun dibuka pada bulan Januari - Maret</p>
                <p><strong>Syarat Pendaftaran:</strong></p>
                <ul>
                    <li>Usia minimal 7 tahun</li>
                    <li>Membawa fotokopi akta kelahiran</li>
                    <li>Membawa fotokopi KTP orang tua</li>
                    <li>Mengisi formulir pendaftaran</li>
                </ul>
            </div>
        </div>
    </div>

    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-info-circle"></i> Informasi Program</h5>
            </div>
            <div class="card-body">
                <p><strong>Program Hafalan:</strong></p>
                <ul>
                    <li>Program Tahfidz 30 Juz</li>
                    <li>Program Tahfidz Juz 30</li>
                    <li>Program Tahfidz Pilihan</li>
                </ul>
                <p><strong>Metode Pembelajaran:</strong></p>
                <ul>
                    <li>Setoran harian kepada ustadz</li>
                    <li>Monitoring melalui sistem digital</li>
                    <li>Laporan berkala kepada orang tua</li>
                </ul>
            </div>
        </div>
    </div>

    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-question-circle"></i> FAQ</h5>
            </div>
            <div class="card-body">
                <h6>Bagaimana cara mengakses monitoring hafalan?</h6>
                <p>Anda dapat mengakses menu Monitoring setelah melakukan login dengan akun yang telah diberikan.</p>

                <h6 class="mt-3">Siapa saja yang bisa mengakses sistem?</h6>
                <p>Sistem dapat diakses oleh Admin, Ustadz, dan Orang Tua Santri dengan hak akses yang berbeda sesuai peran masing-masing.</p>

                <h6 class="mt-3">Bagaimana cara melihat perkembangan hafalan anak?</h6>
                <p>Setelah login sebagai Orang Tua, Anda akan langsung melihat dashboard yang menampilkan statistik dan perkembangan hafalan anak Anda.</p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\SIMHAFAL\resources\views/home/info.blade.php ENDPATH**/ ?>