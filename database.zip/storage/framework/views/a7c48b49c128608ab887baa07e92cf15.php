

<?php $__env->startSection('title', 'Tentang Kami - SIMHAFAL'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-0">Tentang Pondok Pesantren Hilyatul Irsyad</h3>
            </div>
            <div class="card-body">
                <h5>Visi</h5>
                <p>Menjadi lembaga pendidikan Islam terdepan dalam mencetak generasi penghafal Al-Qur'an yang berakhlak mulia dan bermanfaat bagi umat.</p>

                <h5 class="mt-4">Misi</h5>
                <ul>
                    <li>Menyelenggarakan pendidikan Al-Qur'an dengan metode yang efektif dan menyenangkan</li>
                    <li>Membina akhlak mulia berdasarkan Al-Qur'an dan Sunnah</li>
                    <li>Mengembangkan sistem monitoring yang transparan dan akuntabel</li>
                    <li>Membangun kerjasama dengan orang tua dalam mendidik anak</li>
                </ul>

                <h5 class="mt-4">Sejarah</h5>
                <p>
                    Pondok Pesantren Hilyatul Irsyad didirikan dengan tujuan untuk memberikan 
                    pendidikan Al-Qur'an yang berkualitas kepada generasi muda. Dengan dukungan 
                    teknologi modern, kami mengembangkan sistem monitoring hafalan yang memudahkan 
                    orang tua dan ustadz dalam memantau perkembangan hafalan setiap santri.
                </p>

                <h5 class="mt-4">Kontak</h5>
                <p>
                    <i class="bi bi-geo-alt"></i> Alamat: Jl. Pesantren No. 123, Kecamatan, Kota<br>
                    <i class="bi bi-telephone"></i> Telepon: (021) 1234-5678<br>
                    <i class="bi bi-envelope"></i> Email: info@hilyatulirsyad.ac.id
                </p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\SIMHAFAL\resources\views/home/tentang.blade.php ENDPATH**/ ?>