

<?php $__env->startSection('title', 'Dashboard Ustadz - SIMHAFAL'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="bi bi-speedometer2"></i> Dashboard Ustadz</h2>
</div>

<div class="row mb-4">
    <div class="col-md-4 mb-3">
        <div class="card stat-card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">Total Santri</h6>
                        <h3 class="mb-0"><?php echo e($totalSantri); ?></h3>
                    </div>
                    <div class="text-primary">
                        <i class="bi bi-people" style="font-size: 2.5rem;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card stat-card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">Total Hafalan</h6>
                        <h3 class="mb-0"><?php echo e($totalHafalan); ?></h3>
                    </div>
                    <div class="text-info">
                        <i class="bi bi-book" style="font-size: 2.5rem;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card stat-card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">Hafalan Selesai</h6>
                        <h3 class="mb-0"><?php echo e($hafalanSelesai); ?></h3>
                    </div>
                    <div class="text-success">
                        <i class="bi bi-check-circle" style="font-size: 2.5rem;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Menu Utama</h5>
            </div>
            <div class="card-body">
                <div class="list-group">
                    <a href="<?php echo e(route('ustadz.santri.index')); ?>" class="list-group-item list-group-item-action">
                        <i class="bi bi-people"></i> Daftar Santri
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Hafalan Terbaru</h5>
            </div>
            <div class="card-body">
                <?php $__empty_1 = true; $__currentLoopData = $hafalanTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="border-bottom pb-2 mb-2">
                        <strong><?php echo e($h->santri->nama); ?></strong><br>
                        <small class="text-muted">
                            Juz <?php echo e($h->juz ?? '-'); ?> | 
                            <?php echo e($h->surat ?? '-'); ?> | 
                            Status: <span class="badge bg-<?php echo e($h->status == 'selesai' ? 'success' : 'warning'); ?>">
                                <?php echo e(ucfirst($h->status)); ?>

                            </span>
                        </small>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted mb-0">Belum ada hafalan</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\SIMHAFAL\resources\views/ustadz/dashboard.blade.php ENDPATH**/ ?>