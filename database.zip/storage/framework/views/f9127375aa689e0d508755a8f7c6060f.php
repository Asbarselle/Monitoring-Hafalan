

<?php $__env->startSection('title', 'Daftar Santri - SIMHAFAL'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="bi bi-people"></i> Daftar Santri</h2>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>NIS</th>
                        <th>Nama</th>
                        <th>Total Hafalan</th>
                        <th>Hafalan Selesai</th>
                        <th>Progres</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $santri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration + ($santri->currentPage() - 1) * $santri->perPage()); ?></td>
                            <td><?php echo e($s->nis); ?></td>
                            <td><?php echo e($s->nama); ?></td>
                            <td><?php echo e($s->hafalan->count()); ?></td>
                            <td><?php echo e($s->hafalan->where('status', 'selesai')->count()); ?></td>
                            <td>
                                <div class="progress" style="height: 20px;">
                                    <div class="progress-bar" role="progressbar" 
                                         style="width: <?php echo e($s->progres_hafalan); ?>%">
                                        <?php echo e(number_format($s->progres_hafalan, 1)); ?>%
                                    </div>
                                </div>
                            </td>
                            <td>
                                <a href="<?php echo e(route('ustadz.santri.show', $s->id)); ?>" class="btn btn-sm btn-primary">
                                    <i class="bi bi-eye"></i> Lihat
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center">Tidak ada data</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            <?php echo e($santri->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\SIMHAFAL\resources\views/ustadz/santri/index.blade.php ENDPATH**/ ?>