

<?php $__env->startSection('title', 'Dashboard Admin - SIMHAFAL'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="bi bi-speedometer2"></i> Dashboard Admin</h2>
</div>

<div class="row mb-4">
    <div class="col-md-3 mb-3">
        <div class="card stat-card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">Total User</h6>
                        <h3 class="mb-0"><?php echo e($totalUsers); ?></h3>
                    </div>
                    <div class="text-primary">
                        <i class="bi bi-people" style="font-size: 2.5rem;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card stat-card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">Total Santri</h6>
                        <h3 class="mb-0"><?php echo e($totalSantri); ?></h3>
                    </div>
                    <div class="text-success">
                        <i class="bi bi-person-badge" style="font-size: 2.5rem;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card stat-card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">Total Hafalan</h6>
                        <h3 class="mb-0"><?php echo e($totalHafalan); ?></h3>
                    </div>
                    <div class="text-info">
                        <i class="bi bi-book" style="font-size: 2.5rem;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card stat-card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">Hafalan Selesai</h6>
                        <h3 class="mb-0"><?php echo e($hafalanSelesai); ?></h3>
                    </div>
                    <div class="text-warning">
                        <i class="bi bi-check-circle" style="font-size: 2.5rem;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Menu Utama</h5>
            </div>
            <div class="card-body">
                <div class="list-group">
                    <a href="<?php echo e(route('admin.users')); ?>" class="list-group-item list-group-item-action">
                        <i class="bi bi-people"></i> Kelola User
                    </a>
                    <a href="<?php echo e(route('admin.santri')); ?>" class="list-group-item list-group-item-action">
                        <i class="bi bi-person-badge"></i> Kelola Santri
                    </a>
                    <a href="<?php echo e(route('admin.hafalan')); ?>" class="list-group-item list-group-item-action">
                        <i class="bi bi-book"></i> Data Hafalan
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Statistik Hafalan</h5>
            </div>
            <div class="card-body">
                <?php $__currentLoopData = $statistikHafalan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mb-2">
                        <div class="d-flex justify-content-between mb-1">
                            <span><?php echo e(ucfirst($stat->status)); ?></span>
                            <span><?php echo e($stat->total); ?></span>
                        </div>
                        <div class="progress">
                            <div class="progress-bar" role="progressbar" 
                                 style="width: <?php echo e(($stat->total / $totalHafalan) * 100); ?>%">
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\SIMHAFAL\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>